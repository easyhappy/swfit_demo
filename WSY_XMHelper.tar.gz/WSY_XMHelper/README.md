WSY_XMHelper
============

A LOL live video open and download  project, Use ReactiveCocoa to programing,  Based On MVVM Architecture!

#ABOUT MVVM
http://www.objc.io/issue-13/mvvm.html


#THANKS
@Void Main

#LICENSE
`WSY_XMHelper` is released under GNU GENERAL PUBLIC LICENSE.

GNU GENERAL PUBLIC LICENSE
Version 2, June 1991

Copyright (C) 1989, 1991 Free Software Foundation, Inc., <http://fsf.org/>
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

>**Copyright &copy; 2014 Wilson Yuan.**
